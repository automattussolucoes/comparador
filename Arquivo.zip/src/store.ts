import { create } from 'zustand';
import { supabase } from './lib/supabase';

export interface ProductType {
  id: string;
  name: string;
  icon: string;
}

export interface Category {
  id: string;
  name: string;
  productTypeId: string;
}

export interface Specification {
  id: string;
  name: string;
  productTypeId: string;
}

export interface Product {
  id: string;
  name: string;
  price: string;
  image: string;
  link: string;
  categoryId: string;
  specs: Record<string, string>; // specId -> value
}

interface AppState {
  productTypes: ProductType[];
  categories: Category[];
  specifications: Specification[];
  products: Product[];
  isLoading: boolean;
  
  fetchData: () => Promise<void>;

  addProductType: (pt: Omit<ProductType, 'id'>) => Promise<void>;
  updateProductType: (id: string, pt: Partial<ProductType>) => Promise<void>;
  deleteProductType: (id: string) => Promise<void>;

  addCategory: (cat: Omit<Category, 'id'>) => Promise<void>;
  updateCategory: (id: string, cat: Partial<Category>) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;

  addSpecification: (spec: Omit<Specification, 'id'>) => Promise<void>;
  updateSpecification: (id: string, spec: Partial<Specification>) => Promise<void>;
  deleteSpecification: (id: string) => Promise<void>;

  addProduct: (prod: Omit<Product, 'id'>) => Promise<void>;
  updateProduct: (id: string, prod: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
}

export const useAppStore = create<AppState>((set, get) => ({
  productTypes: [],
  categories: [],
  specifications: [],
  products: [],
  isLoading: false,

  fetchData: async () => {
    set({ isLoading: true });
    try {
      const [typesRes, catsRes, specsRes, prodsRes] = await Promise.all([
        supabase.from('product_types').select('*').order('created_at', { ascending: true }),
        supabase.from('categories').select('*').order('created_at', { ascending: true }),
        supabase.from('specifications').select('*').order('created_at', { ascending: true }),
        supabase.from('products').select('*').order('created_at', { ascending: true })
      ]);

      if (typesRes.error) throw typesRes.error;
      if (catsRes.error) throw catsRes.error;
      if (specsRes.error) throw specsRes.error;
      if (prodsRes.error) throw prodsRes.error;

      set({
        productTypes: typesRes.data || [],
        categories: (catsRes.data || []).map(c => ({ id: c.id, name: c.name, productTypeId: c.product_type_id })),
        specifications: (specsRes.data || []).map(s => ({ id: s.id, name: s.name, productTypeId: s.product_type_id })),
        products: (prodsRes.data || []).map(p => ({
          id: p.id,
          name: p.name,
          price: p.price,
          image: p.image,
          link: p.link,
          categoryId: p.category_id,
          specs: p.specs || {}
        }))
      });
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      set({ isLoading: false });
    }
  },

  addProductType: async (pt) => {
    const { data, error } = await supabase.from('product_types').insert([pt]).select().single();
    if (error) console.error('Error adding product type:', error);
    if (!error && data) {
      set((state) => ({ productTypes: [...state.productTypes, data] }));
    }
  },
  
  updateProductType: async (id, pt) => {
    const { data, error } = await supabase.from('product_types').update(pt).eq('id', id).select().single();
    if (error) console.error('Error updating product type:', error);
    if (!error && data) {
      set((state) => ({
        productTypes: state.productTypes.map(p => p.id === id ? data : p)
      }));
    }
  },
  
  deleteProductType: async (id) => {
    const { error } = await supabase.from('product_types').delete().eq('id', id);
    if (error) console.error('Error deleting product type:', error);
    if (!error) {
      set((state) => ({
        productTypes: state.productTypes.filter(p => p.id !== id),
        categories: state.categories.filter(c => c.productTypeId !== id),
        specifications: state.specifications.filter(s => s.productTypeId !== id),
        products: state.products.filter(p => {
          const cat = state.categories.find(c => c.id === p.categoryId);
          return cat?.productTypeId !== id;
        })
      }));
    }
  },

  addCategory: async (cat) => {
    const { data, error } = await supabase.from('categories').insert([{
      name: cat.name,
      product_type_id: cat.productTypeId
    }]).select().single();
    
    if (error) console.error('Error adding category:', error);
    if (!error && data) {
      set((state) => ({ 
        categories: [...state.categories, { id: data.id, name: data.name, productTypeId: data.product_type_id }] 
      }));
    }
  },
  
  updateCategory: async (id, cat) => {
    const updateData: any = {};
    if (cat.name) updateData.name = cat.name;
    if (cat.productTypeId) updateData.product_type_id = cat.productTypeId;
    
    const { data, error } = await supabase.from('categories').update(updateData).eq('id', id).select().single();
    if (error) console.error('Error updating category:', error);
    if (!error && data) {
      set((state) => ({
        categories: state.categories.map(c => c.id === id ? { id: data.id, name: data.name, productTypeId: data.product_type_id } : c)
      }));
    }
  },
  
  deleteCategory: async (id) => {
    const { error } = await supabase.from('categories').delete().eq('id', id);
    if (error) console.error('Error deleting category:', error);
    if (!error) {
      set((state) => ({
        categories: state.categories.filter(c => c.id !== id),
        products: state.products.filter(p => p.categoryId !== id)
      }));
    }
  },

  addSpecification: async (spec) => {
    const { data, error } = await supabase.from('specifications').insert([{
      name: spec.name,
      product_type_id: spec.productTypeId
    }]).select().single();
    
    if (error) console.error('Error adding specification:', error);
    if (!error && data) {
      set((state) => ({ 
        specifications: [...state.specifications, { id: data.id, name: data.name, productTypeId: data.product_type_id }] 
      }));
    }
  },
  
  updateSpecification: async (id, spec) => {
    const updateData: any = {};
    if (spec.name) updateData.name = spec.name;
    if (spec.productTypeId) updateData.product_type_id = spec.productTypeId;
    
    const { data, error } = await supabase.from('specifications').update(updateData).eq('id', id).select().single();
    if (error) console.error('Error updating specification:', error);
    if (!error && data) {
      set((state) => ({
        specifications: state.specifications.map(s => s.id === id ? { id: data.id, name: data.name, productTypeId: data.product_type_id } : s)
      }));
    }
  },
  
  deleteSpecification: async (id) => {
    const { error } = await supabase.from('specifications').delete().eq('id', id);
    if (error) console.error('Error deleting specification:', error);
    if (!error) {
      set((state) => ({
        specifications: state.specifications.filter(s => s.id !== id),
        products: state.products.map(p => {
          const newSpecs = { ...p.specs };
          delete newSpecs[id];
          return { ...p, specs: newSpecs };
        })
      }));
    }
  },

  addProduct: async (prod) => {
    const { data, error } = await supabase.from('products').insert([{
      name: prod.name,
      price: prod.price,
      image: prod.image,
      link: prod.link,
      category_id: prod.categoryId,
      specs: prod.specs
    }]).select().single();
    
    if (error) console.error('Error adding product:', error);
    if (!error && data) {
      set((state) => ({ 
        products: [...state.products, {
          id: data.id,
          name: data.name,
          price: data.price,
          image: data.image,
          link: data.link,
          categoryId: data.category_id,
          specs: data.specs || {}
        }] 
      }));
    }
  },
  
  updateProduct: async (id, prod) => {
    const updateData: any = { ...prod };
    if (prod.categoryId) {
      updateData.category_id = prod.categoryId;
      delete updateData.categoryId;
    }
    
    const { data, error } = await supabase.from('products').update(updateData).eq('id', id).select().single();
    if (error) console.error('Error updating product:', error);
    if (!error && data) {
      set((state) => ({
        products: state.products.map(p => p.id === id ? {
          id: data.id,
          name: data.name,
          price: data.price,
          image: data.image,
          link: data.link,
          categoryId: data.category_id,
          specs: data.specs || {}
        } : p)
      }));
    }
  },
  
  deleteProduct: async (id) => {
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) console.error('Error deleting product:', error);
    if (!error) {
      set((state) => ({
        products: state.products.filter(p => p.id !== id)
      }));
    }
  },
}));
